import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { College } from '../model/college';
import { CollegeServiceService } from '../service/college-service.service';

@Component({
  selector: 'app-getcollegedetailsbycoursename',
  templateUrl: './getcollegedetailsbycoursename.component.html',
  styleUrls: ['./getcollegedetailsbycoursename.component.css']
})
export class GetcollegedetailsbycoursenameComponent implements OnInit {

  Name:String="";
  msg:String="";
  col:College[]=[];
  
    constructor(private bs:CollegeServiceService,private router:Router) { 
      }
  
    
    ngOnInit() {
    }
    public CollegeBycourseName(){
      console.log(this.Name);
      this.bs.extractBycoursename(this.Name).subscribe(response=>{
        this.col=response;
        console.log(response);
          alert(this.Name);
        
      })
    }
}
