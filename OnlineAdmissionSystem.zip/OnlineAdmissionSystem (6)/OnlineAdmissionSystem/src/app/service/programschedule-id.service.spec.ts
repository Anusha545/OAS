import { TestBed } from '@angular/core/testing';

import { ProgramscheduleIdService } from './programschedule-id.service';

describe('ProgramscheduleIdService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProgramscheduleIdService = TestBed.get(ProgramscheduleIdService);
    expect(service).toBeTruthy();
  });
});
