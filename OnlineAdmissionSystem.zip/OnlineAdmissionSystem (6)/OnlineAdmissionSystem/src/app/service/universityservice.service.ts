import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { University } from '../model/university';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class UniversityserviceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addUniversity(university:University):Observable<any>{
    return this.http.post<any>(this.url+"addUniversity",university);
  }
  public extractUniversity():Observable<any>{
    return this.http.get(this.url+"getUniversityDetails");
  }
  
  public deleteUniversity(Id:number):Observable<any>{
    return this.http.delete(this.url+`deleteUniversityById/${Id}`);
  }
  
  public extractById(Id:number):Observable<any>{
    return this.http.get(this.url+`getUniversityById/${Id}`);
    
  }
  public updateById(university:University,universityId:number):Observable<any>{
    return this.http.put<any>(this.url+`UpdateUniversity/${universityId}`,university);
  }
  public extractByName(collegeName:String):Observable<any>{
    return this.http.get<any>(this.url+`getUniversityCollege/${collegeName}`);
  }
  public extractBycity(city:String):Observable<any>{
    return this.http.get<any>(this.url+`getUniversityCity/${city}`);
  }
 
}
  
