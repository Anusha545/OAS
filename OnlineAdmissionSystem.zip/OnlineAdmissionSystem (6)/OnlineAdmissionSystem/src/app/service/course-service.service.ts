import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Course } from '../model/course';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class CourseServiceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addCourse(course:Course):Observable<any>{
    return this.http.post<any>(this.url+"createcourse",course);
  }
  public extractCourse():Observable<any>{
    return this.http.get(this.url+"getAllCourseDetails");
  }

  public deleteCourse(Id:number):Observable<any>{
    return this.http.delete(this.url+`deleteCourse/${Id}`);
  }
  public extractById(Id:number):Observable<any>{
    return this.http.get(this.url+`getCourseDetailsByCourseId/${Id}`);
    
  }
  public updateById(course:Course,courseId:number):Observable<any>{
    return this.http.put<any>(this.url+`UpdateCourseDetails/${courseId}`,course);
  }
  public extractByCourseName(courseName:String):Observable<any>{
    return this.http.get<any>(this.url+`getCourseDetailsByCourseName/${courseName}`);
    
  }
  public extractByEligibility(eligiblity:String):Observable<any>{
    return this.http.get<any>(this.url+`getCourseDetailsByEligibility/${eligiblity}`);
  }
  public extractByCollegeName(collegeName:String):Observable<any>{
    return this.http.get<any>(this.url+`getCourseDetailsByCollegeName/${collegeName}`);
    
  }


}