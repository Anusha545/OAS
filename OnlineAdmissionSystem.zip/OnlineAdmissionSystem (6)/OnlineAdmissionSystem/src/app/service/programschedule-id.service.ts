import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Address } from '../model/address';
import { ProgramScheduleId } from '../model/program-schedule-id';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class ProgramscheduleIdService {

  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addSchedule(ProgramScheduleId:ProgramScheduleId):Observable<any>{
    return this.http.post<any>(this.url+"createProgramSchedule",ProgramScheduleId);
  }
  public extractProgram():Observable<any>{
    return this.http.get(this.url+"getProgramScheduleDetails");
  }
  
  public deleteProgram(Id:number):Observable<any>{
    return this.http.delete(this.url+`deleteProgramScheduleById/${Id}`);
  }
  
  public extractById(Id:number):Observable<any>{
    return this.http.get(this.url+`getProgramScheduleById/${Id}`);
    
  }
  public updateById(programschedule:ProgramScheduleId,scheduleid:number):Observable<any>{
    return this.http.put<any>(this.url+`UpdateProgramSchedule/${scheduleid}`,programschedule);
  }

  public extractByName(collegeName:String):Observable<any>{
    return this.http.get<any>(this.url+`getProgramScheduleByCollegeName/${collegeName}`);
    
  }
  public extractByDate(startDate:String):Observable<any>{
    return this.http.get<any>(this.url+`getProgramScheduleByDate/${startDate}`);
    
  }
  
}

