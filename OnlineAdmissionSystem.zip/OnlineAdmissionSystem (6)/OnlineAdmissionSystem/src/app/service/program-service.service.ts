import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payment } from '../model/payment';
import { Program } from '../model/program';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class ProgramServiceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addProgram(program:Program):Observable<any>{
    return this.http.post<any>(this.url+"createProgram",program);
  }
  public extractProgram():Observable<any>{
    return this.http.get(this.url+"getAllProgramDetails");
  }
  
  public deleteProgram(Id:number):Observable<any>{
    return this.http.delete(this.url+`deleteProgramById/${Id}`);
  }
  
  public extractById(Id:number):Observable<any>{
    return this.http.get(this.url+`getProgramById/${Id}`);
    
  }
  public updateById(program:Program,programid:number):Observable<any>{
    return this.http.put<any>(this.url+`updateProgramStatus/${programid}`,program);
  }

  public extractByName(programName:String):Observable<any>{
    return this.http.get<any>(this.url+`getProgramDetailsByName/${programName}`);
    
  }
  public extractByEligibility(eligibility:String):Observable<any>{
    return this.http.get<any>(this.url+`getProgramDetailsByEligibity/${eligibility}`);
  }
}