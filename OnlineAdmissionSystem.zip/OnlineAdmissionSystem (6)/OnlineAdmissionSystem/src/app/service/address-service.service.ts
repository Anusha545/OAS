import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Address } from '../model/address';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class AddressServiceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addAddress(address:Address):Observable<any>{
    return this.http.post<any>(this.url+"createAddress",address);
  }

  public extractAddress():Observable<any>{
    return this.http.get<any>(this.url+"getAddressDetails");
  }
  public deleteAddress(addressId:number):Observable<any>{
    return this.http.delete(this.url+`deleteAddress/${addressId}`);
  }
  public extractById(addressId:number):Observable<any>{
    return this.http.get(this.url+`getAddressById/${addressId}`);
    
  }
  public updateById(address:Address,addressId:number):Observable<any>{
    return this.http.put<any>(this.url+`updateAddress/${addressId}`,address);
  }
}