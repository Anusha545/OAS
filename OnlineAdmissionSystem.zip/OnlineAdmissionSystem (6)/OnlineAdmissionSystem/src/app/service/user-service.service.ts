import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../model/login';
import { User } from '../model/user';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

    url:string=ProjectURL.getUrl();
//put,get,post,delete
  constructor(private http:HttpClient) { }
  public addUser(user:User):Observable<any>{
    return this.http.post<any>(this.url+"createUser",user);
  }
  public extractUser(Id:String):Observable<any>{
    return this.http.get<any>(this.url+`getLogindetailsById/${Id}`)
  }

  //extracting All Users
public extractUsers():Observable<any>{
  return this.http.get(this.url+"getAllUserDetails");
}
//delete userbyid
public deleteUserDetailsById(Id:String):Observable<any>{
  return this.http.delete(this.url+`deleteUserdetailsById/${Id}`);
}

public extractUserById(Id:String):Observable<any>{
  return this.http.get(this.url+`getUserdetailsById/${Id}`);
  
}
public updateUserDetails(user:User,Id:String):Observable<any>{
  return this.http.put<any>(this.url+`UpdateUserdetails/user/${Id}`,user);
}
//extracting ALL login details
public extractLogin():Observable<any>{
  return this.http.get(this.url+"getAllLoginDetails");
}

//delete loginbyid
public deleteLoginDetailsById(Id:String):Observable<any>{
  return this.http.delete(this.url+`deleteLogindetailsById/${Id}`);
}
public extractLoginById(Id:String):Observable<any>{
  return this.http.get(this.url+`getLogindetailsById/${Id}`);
  
}
public updateLoginDetails(login:Login,Id:String):Observable<any>{
  return this.http.put<any>(this.url+`UpdatePassword/login/${Id}`,login);
}
public resetLoginDetails(login:Login,Id:String):Observable<any>{
  return this.http.put<any>(this.url+`ResetPassword/login/${Id}`,login);
}
public sendMail(mail:String):Observable<any>{
  return this.http.get(this.url+`sendMail/${mail}`,{responseType: 'text' });
}
}

