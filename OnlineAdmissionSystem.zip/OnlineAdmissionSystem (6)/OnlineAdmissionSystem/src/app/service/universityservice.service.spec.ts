import { TestBed } from '@angular/core/testing';

import { UniversityserviceService } from './universityservice.service';

describe('UniversityserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UniversityserviceService = TestBed.get(UniversityserviceService);
    expect(service).toBeTruthy();
  });
});
