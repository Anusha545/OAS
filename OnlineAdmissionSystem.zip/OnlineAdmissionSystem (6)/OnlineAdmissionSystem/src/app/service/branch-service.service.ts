import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Branch } from '../model/branch';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class BranchServiceService {

  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addBranch(branch:Branch):Observable<any>{
    return this.http.post<any>(this.url+"createBranch",branch);
  }
  public extractBranch():Observable<any>{
    return this.http.get(this.url+"getAllBranchDetails");
  }
  public deleteBranch(branchName:String):Observable<any>{
    return this.http.delete(this.url+`deleteBranchByName/${branchName}`);
  }

  public extractById(branchId:number):Observable<any>{
    return this.http.get(this.url+`getBranchById/${branchId}`);
    
  }
  public updateById(branch:Branch,branchId:number):Observable<any>{
    return this.http.put<any>(this.url+`updateBranch/${branchId}`,branch);
  }
  public extractBybranchId(Id:number):Observable<any>{
    return this.http.get<any>(this.url+`getBranchById/${Id}`);
  
  }
  public extractBybranchName(name:String):Observable<any>{
    return this.http.get<any>(this.url+`getBranchdeatilsByName/${name}`);
  }
}
