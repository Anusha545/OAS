import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payment } from '../model/payment';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class PaymentServiceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addPayment(payment:Payment):Observable<any>{
    return this.http.post<any>(this.url+"createPayment",payment);
  }
  //extracting payment
public extractPayment():Observable<any>{
  return this.http.get(this.url+"getAllPaymentDeatils");
}

public deletePayment(productId:number):Observable<any>{
  return this.http.delete(this.url+`deletePayment/${productId}`);
}

public extractById(paymentId:number):Observable<any>{
  return this.http.get(this.url+`getPaymentDetailsByPaymentId/${paymentId}`);
  
}
public updateById(payment:Payment,paymentId:number):Observable<any>{
  return this.http.put<any>(this.url+`updatePayment/${paymentId}`,payment);
}
public extractByEmail(paymentEmail:String):Observable<any>{
  return this.http.get<any>(this.url+`getPaymentDetailsByEmail/${paymentEmail}`);
  
}
public extractByStatus(paymentStatus:String):Observable<any>{
  return this.http.get<any>(this.url+`getPaymentDetailsByStatus/${paymentStatus}`);
}

  public extractByApplicationId(applicationId:number):Observable<any>{
    return this.http.get<any>(this.url+`getPaymentDetailsByapplicationId/${applicationId}`);
  
}
public extractByPaymentId(paymentId:number):Observable<any>{
  return this.http.get<any>(this.url+`getPaymentDetailsByPaymentId/${paymentId}`);

}
}

