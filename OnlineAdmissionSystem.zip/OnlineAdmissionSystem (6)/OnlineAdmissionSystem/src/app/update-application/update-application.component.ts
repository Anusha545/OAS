import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Application } from '../model/application';
import { ApplicationServiceService } from '../service/application-service.service';

@Component({
  selector: 'app-update-application',
  templateUrl: './update-application.component.html',
  styleUrls: ['./update-application.component.css']
})
export class UpdateApplicationComponent implements OnInit {

  application:Application;
  applicationId:number;
  bemailId:String="";
  bhighestQualification:String="";
  constructor(private r:ActivatedRoute,private as:ApplicationServiceService,private router:Router) { }

  ngOnInit() {
    this.applicationId=this.r.snapshot.params['p'];
    this.as.extractById(this.applicationId).subscribe(response=>
 {
    this.application=response;
    console.log(response)
   this.bemailId=this.application.emailId;
  this.bhighestQualification=this.application.highestQualification; 
 })
}

public updateApplication(){
  this.application.highestQualification=this.bhighestQualification;
  this.application.emailId=this.bemailId;
  
    this.as.updateById(this.application,this.application.applicationId).subscribe(response=>{
      console.log(response);
      alert("application is updated");
      this.router.navigate(['viewApplication']);
    })
   }
  }