import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  msg:String="";
  users:User[]=[];
    constructor(private userService:UserServiceService,private router:Router) { }
  
    ngOnInit() {
      this.userService.extractUsers().subscribe(response=>{this.users=response;})
       
        }
       public deleteUserDetailsById(Id:String){
          console.log(Id);
          this.userService.deleteUserDetailsById(Id).subscribe(response=>{
            console.log(response);
            this.msg=`${Id}`+" "+"is deleted";
            alert("User Id is deleted");
            window.location.reload();
          })
        }
        public EditUser(Id:String){
          console.log(Id);
          this.router.navigate(['UpdateForm',Id])
        }
  
      
    }
