import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcoursedetailsbyadminComponent } from './viewcoursedetailsbyadmin.component';

describe('ViewcoursedetailsbyadminComponent', () => {
  let component: ViewcoursedetailsbyadminComponent;
  let fixture: ComponentFixture<ViewcoursedetailsbyadminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewcoursedetailsbyadminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewcoursedetailsbyadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
