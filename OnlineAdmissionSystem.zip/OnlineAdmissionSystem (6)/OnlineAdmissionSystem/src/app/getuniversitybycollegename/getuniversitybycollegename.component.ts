import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { University } from '../model/university';
import { UniversityserviceService } from '../service/universityservice.service';

@Component({
  selector: 'app-getuniversitybycollegename',
  templateUrl: './getuniversitybycollegename.component.html',
  styleUrls: ['./getuniversitybycollegename.component.css']
})
export class GetuniversitybycollegenameComponent implements OnInit {
  pcollegeName:String="";
  msg:String="";
  university:University[]=[];
  constructor(private bs:UniversityserviceService,private router:Router) { }

  ngOnInit() {
  }
  public collegeName(){
    console.log(this.pcollegeName);
    this.bs.extractByName(this.pcollegeName).subscribe(response=>{
      this.university=response;
      console.log(response);
        alert(this.pcollegeName);
      
    })
  }
}