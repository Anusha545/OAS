import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewprogramscheduleIdComponent } from './viewprogramschedule-id.component';

describe('ViewprogramscheduleIdComponent', () => {
  let component: ViewprogramscheduleIdComponent;
  let fixture: ComponentFixture<ViewprogramscheduleIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewprogramscheduleIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewprogramscheduleIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
