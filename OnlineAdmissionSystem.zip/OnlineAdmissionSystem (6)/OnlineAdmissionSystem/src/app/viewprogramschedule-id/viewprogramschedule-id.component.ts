import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProgramScheduleId } from '../model/program-schedule-id';
import { ProgramServiceService } from '../service/program-service.service';
import { ProgramscheduleIdService } from '../service/programschedule-id.service';

@Component({
  selector: 'app-viewprogramschedule-id',
  templateUrl: './viewprogramschedule-id.component.html',
  styleUrls: ['./viewprogramschedule-id.component.css']
})
export class ViewprogramscheduleIdComponent implements OnInit {

  
  msg:String="";
program:ProgramScheduleId[]=[];
  constructor(private programService:ProgramscheduleIdService,private router:Router) { }

  ngOnInit() {
    this.programService.extractProgram().subscribe(response=>{ this.program=response;})}

    public deleteProgram(programId:number){
      console.log(programId);
      this.programService.deleteProgram(programId).subscribe(response=>{
        console.log(response);
        this.msg=`${programId}`+" "+"is deleted";
        alert("program Id is deleted");
        window.location.reload();
      }) 

}
public EditProgram(programId:number){
  console.log(programId);
  this.router.navigate(['UpdateProgramSchedule',programId])
}
}
