import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { College } from '../model/college';
import { CollegeServiceService } from '../service/college-service.service';

@Component({
  selector: 'app-getcollegedetailsbycollegename',
  templateUrl: './getcollegedetailsbycollegename.component.html',
  styleUrls: ['./getcollegedetailsbycollegename.component.css']
})
export class GetcollegedetailsbycollegenameComponent implements OnInit {

  Name:String="";
  msg:String="";
  college:College=new College();
  
    constructor(private bs:CollegeServiceService,private router:Router) { 
      }
  
    
    ngOnInit() {
    }
    public CollegeBycollegeName(){
      console.log(this.Name);
      this.bs.extractBycollegename(this.Name).subscribe(response=>{
        //this.Name=response;
        this.college=response;
        console.log(response);
          alert(this.Name);
        
      })
    }
}

