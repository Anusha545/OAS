import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProgramScheduleId } from '../model/program-schedule-id';
import { ProgramscheduleIdService } from '../service/programschedule-id.service';

@Component({
  selector: 'app-getpsbycollegename',
  templateUrl: './getpsbycollegename.component.html',
  styleUrls: ['./getpsbycollegename.component.css']
})
export class GetpsbycollegenameComponent implements OnInit {

  Name:String="";
  msg:String="";
  program:ProgramScheduleId[]=[];
  
    constructor(private bs:ProgramscheduleIdService,private router:Router) { 
      }
  
    
    ngOnInit() {
    }
    public ProgramScheduleBycollegeName(){
      console.log(this.Name);
      this.bs.extractByName(this.Name).subscribe(response=>{
        this.program=response;
        console.log(response);
          alert(this.Name);
        
      })
    }
}