import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetpsbycollegenameComponent } from './getpsbycollegename.component';

describe('GetpsbycollegenameComponent', () => {
  let component: GetpsbycollegenameComponent;
  let fixture: ComponentFixture<GetpsbycollegenameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetpsbycollegenameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetpsbycollegenameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
