import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../model/course';
import { CourseServiceService } from '../service/course-service.service';


@Component({
  selector: 'app-get-detailsby-eligiblity',
  templateUrl: './get-detailsby-eligiblity.component.html',
  styleUrls: ['./get-detailsby-eligiblity.component.css']
})
export class GetDetailsbyEligiblityComponent implements OnInit {

  eligiblity:String;
  msg:String="";
  courses:Course[]=[];

  constructor(private bs:CourseServiceService,private router:Router) { 

  }

  ngOnInit() {
  }

  public CourseEligibility(){
    console.log(this.eligiblity);
    this.bs.extractByEligibility(this.eligiblity).subscribe(response=>{
      this.courses=response;
      console.log(response);
        alert(this.eligiblity);
      
  
  })

}
}
