import { Component, OnInit } from '@angular/core';
import { Course } from '../model/course';
import { CourseServiceService } from '../service/course-service.service';

@Component({
  selector: 'app-createcourse',
  templateUrl: './createcourse.component.html',
  styleUrls: ['./createcourse.component.css']
})
export class CreatecourseComponent implements OnInit {

  course:Course=new Course();
 
  errorMsg:String="hii";
  constructor(private ps:CourseServiceService) { }

  ngOnInit() {
  }
  public createCourse():void{
    console.log(this.course);
    this.ps.addCourse(this.course).subscribe((p)=>
    {
      this.course=p;
      console.log(this.course);
      this.errorMsg=(p.errorMsg);
      console.log(this.errorMsg);
      alert(this.errorMsg);
      
          
    })
  }
}
