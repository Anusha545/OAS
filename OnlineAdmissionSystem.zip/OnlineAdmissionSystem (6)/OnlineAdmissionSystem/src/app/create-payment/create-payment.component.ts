import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-payment',
  templateUrl: './create-payment.component.html',
  styleUrls: ['./create-payment.component.css']
})
export class CreatePaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
