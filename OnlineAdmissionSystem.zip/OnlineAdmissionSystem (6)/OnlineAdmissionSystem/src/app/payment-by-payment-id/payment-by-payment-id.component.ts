import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Error } from '../model/error';
import { Payment } from '../model/payment';
import { PaymentServiceService } from '../service/payment-service.service';

@Component({
  selector: 'app-payment-by-payment-id',
  templateUrl: './payment-by-payment-id.component.html',
  styleUrls: ['./payment-by-payment-id.component.css']
})
export class PaymentByPaymentIdComponent implements OnInit {
  paymentId:number;
  msg:String="";
  payment:Payment;
 
  errorMsg:String="";

  

  constructor(private paymentService:PaymentServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public PaymentByPaymentId(){
    console.log(this.paymentId);
    this.paymentService.extractByPaymentId(this.paymentId).subscribe(response=>this.getResponse(response),
         
  )
}
getResponse(response)
{
this.payment=response;
this.errorMsg=(response.errorMsg);


}
}



