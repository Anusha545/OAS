import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByPaymentIdComponent } from './payment-by-payment-id.component';

describe('PaymentByPaymentIdComponent', () => {
  let component: PaymentByPaymentIdComponent;
  let fixture: ComponentFixture<PaymentByPaymentIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentByPaymentIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentByPaymentIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
