import { Component, OnInit } from '@angular/core';
import { Payment } from '../model/payment';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentServiceService } from '../service/payment-service.service';



@Component({
  selector: 'app-update-payment',
  templateUrl: './update-payment.component.html',
  styleUrls: ['./update-payment.component.css']
})
export class UpdatePaymentComponent implements OnInit {
payment:Payment;
paymentId:number;
pAmount:number;
pDescription:String="";
pEmail:String="";
  constructor(private r:ActivatedRoute,private paymentService:PaymentServiceService,private router:Router) { }

  ngOnInit() {
    this.paymentId=this.r.snapshot.params['p'];
    this.paymentService.extractById(this.paymentId).subscribe(response=>
     {
  this.payment=response;
  this.pAmount=this.payment.paymentAmount;
  this.pDescription=this.payment.paymentDescription;
  this.pEmail=this.payment.emailId;  
 })
  }
  public UpdatePayment(){
    this.payment.emailId=this.pEmail;
    this.payment.paymentAmount=this.pAmount;
    this.payment.paymentDescription=this.pDescription;
  this.paymentService.updateById(this.payment,this.payment.paymentId).subscribe(response=>{
        console.log(response);
        if(response!=null)
      alert("payment is updated");
      this.router.navigate(['viewPayment']);
    })
   }
  
  

}
