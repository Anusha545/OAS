import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Branch } from '../model/branch';
import { BranchServiceService } from '../service/branch-service.service';

@Component({
  selector: 'app-get-branch-by-name',
  templateUrl: './get-branch-by-name.component.html',
  styleUrls: ['./get-branch-by-name.component.css']
})
export class GetBranchByNameComponent implements OnInit {

  branchName:String;
  msg:String="";
  branch:Branch[]=[];

  constructor(private bs:BranchServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public BranchName(){
    console.log(this.branchName);
    this.bs.extractBybranchName(this.branchName).subscribe(response=>{
      this.branch=response;
      console.log(response);
        alert(this.branchName);
      
    })
  }
}