import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetBranchByNameComponent } from './get-branch-by-name.component';

describe('GetBranchByNameComponent', () => {
  let component: GetBranchByNameComponent;
  let fixture: ComponentFixture<GetBranchByNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetBranchByNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetBranchByNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
