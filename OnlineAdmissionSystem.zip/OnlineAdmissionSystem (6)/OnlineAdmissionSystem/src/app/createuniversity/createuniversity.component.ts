import { Component, OnInit } from '@angular/core';
import { University } from '../model/university';
import { UniversityserviceService } from '../service/universityservice.service';
import { UniversityServiceService } from '../university-service.service';

@Component({
  selector: 'app-createuniversity',
  templateUrl: './createuniversity.component.html',
  styleUrls: ['./createuniversity.component.css']
})
export class CreateuniversityComponent implements OnInit {
university:University=new University(); 
  msg:String="";
  errormsg:String="";
  errorMsg:String="";
  constructor(private ps:UniversityserviceService) { }

  ngOnInit() {
  }
  public createUniversity():void{
    console.log(this.university);
    this.ps.addUniversity(this.university).subscribe((p)=>
    {
      this.university=p;
      this.errorMsg=(p.errorMsg);
      console.log(p.errorMsg);
      if(p!=null){
        alert("university has been added");
      }
    })
  
  }
}
  