import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateuniversityComponent } from './createuniversity.component';

describe('CreateuniversityComponent', () => {
  let component: CreateuniversityComponent;
  let fixture: ComponentFixture<CreateuniversityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateuniversityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateuniversityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
