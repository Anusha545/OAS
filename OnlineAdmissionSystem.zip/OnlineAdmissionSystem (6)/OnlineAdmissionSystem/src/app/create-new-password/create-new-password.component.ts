import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-create-new-password',
  templateUrl: './create-new-password.component.html',
  styleUrls: ['./create-new-password.component.css']
})
export class CreateNewPasswordComponent implements OnInit {
  otp:String="";
  newpassword:String="";
  confirmpassword:String="";
  email:String="";
  msg:String="";
  loginId:string="";
  login:Login=new Login();
  constructor(private r:ActivatedRoute,private userService:UserServiceService,private router:Router) { }

  ngOnInit() {
    //this.loginId=this.r.snapshot.params['r'];
    
}
public resetPassword(){
  this.userService.sendMail(this.email).subscribe(p=>{
    this.msg=p;
    console.log(p);
    this.userService.extractLoginById(this.loginId).subscribe(response=>{
      this.login=response;
      this.newpassword=this.login.password;
     });
    this.login.loginId=this.loginId;
    this.login.password=this.newpassword;
    if(((p)==(this.otp))||((this.newpassword)==(this.confirmpassword)))
    {
      this.userService.resetLoginDetails(this.login,this.login.loginId).subscribe(response=>{
        console.log(response);
        alert("Password is reseted");
        this.router.navigate(['login']);
      })
      
     
      }
  
 
})

}
}