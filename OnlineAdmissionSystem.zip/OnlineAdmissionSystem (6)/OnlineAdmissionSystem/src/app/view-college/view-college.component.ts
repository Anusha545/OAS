import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { College } from '../model/college';
import { CollegeServiceService } from '../service/college-service.service';

@Component({
  selector: 'app-view-college',
  templateUrl: './view-college.component.html',
  styleUrls: ['./view-college.component.css']
})
export class ViewCollegeComponent implements OnInit {

  msg:String="";
  colleges:College[]=[];

  constructor(private cs:CollegeServiceService,private router:Router) { }

  ngOnInit() {
    this.cs.extractCollege().subscribe(response=>{ this.colleges=response;})}
   
    public deleteCollege(Id:number){
      console.log(Id);
      this.cs.deleteCollege(Id).subscribe(response=>{
        console.log(response);
        this.msg=`${Id}`+" "+"is deleted";
        alert("College is deleted");
        window.location.reload();
      }) 
    }
      public EditCollege(Id:number){
        console.log(Id);
        this.router.navigate(['CollegeUpdate',Id])
      }

}
    


