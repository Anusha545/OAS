import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetcollegedetailsbyprogramnameComponent } from './getcollegedetailsbyprogramname.component';

describe('GetcollegedetailsbyprogramnameComponent', () => {
  let component: GetcollegedetailsbyprogramnameComponent;
  let fixture: ComponentFixture<GetcollegedetailsbyprogramnameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetcollegedetailsbyprogramnameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetcollegedetailsbyprogramnameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
