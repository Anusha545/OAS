import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Branch } from '../model/branch';
import { BranchServiceService } from '../service/branch-service.service';

@Component({
  selector: 'app-view-branch',
  templateUrl: './view-branch.component.html',
  styleUrls: ['./view-branch.component.css']
})
export class ViewBranchComponent implements OnInit {

  msg:String="";
branches:Branch[]=[];

  constructor(private branchService:BranchServiceService,private router:Router) { }

  ngOnInit() {
    this.branchService.extractBranch().subscribe(response=>{ this.branches=response;})}
   
    public deleteBranch(branchName:String){
      console.log(branchName);
      this.branchService.deleteBranch(branchName).subscribe(response=>{
        console.log(response);
        this.msg=`${branchName}`+" "+"is deleted";
        alert("branchName is deleted");
        window.location.reload();
      }) 
    }
      public EditBranch(branchId:number){
        console.log(branchId);
        this.router.navigate(['BranchUpdate',branchId])
      }

}
    

