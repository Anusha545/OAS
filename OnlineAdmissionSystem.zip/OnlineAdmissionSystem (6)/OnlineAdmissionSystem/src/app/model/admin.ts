import { User } from "./user";

export class Admin {
    public adminId:number;
    public user:User=new User();
}
