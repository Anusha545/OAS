
import { Branch } from "./branch";
import { College } from "./college";

export class Course {
    public courseId:number;
    public courseName:String;
    public eligiblity:String;
    public college:College=new College();
    public branches:Branch[]=[];

}
