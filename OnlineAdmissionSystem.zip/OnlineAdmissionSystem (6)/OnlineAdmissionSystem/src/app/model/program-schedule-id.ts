import { Branch } from "./branch";
import { College } from "./college";
import { Course } from "./course";
import { Program } from "./program";
import { University } from "./university"

export class ProgramScheduleId {
    public scheduleId:number;
    public startDate:Date;
    public endDate:Date;
    public branch : Branch=new Branch();
    public course:  Course=new Course();
    public program: Program=new Program();
    public college: College=new College();
    public university:University=new University();

}
