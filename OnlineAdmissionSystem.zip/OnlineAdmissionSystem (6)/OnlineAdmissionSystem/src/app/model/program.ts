export class Program {
    public degreeOffered :String;
    public duration: String;
    public eligibility: String;
    public programName: String;
    public programid:number;
}
