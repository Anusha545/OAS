export class Error {
    public date:Date;
    public errorMsg:String;
    public validationMsg:String;
}
