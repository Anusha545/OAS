export class Login {
    public loginId:String;
    public password:String;
    public  role:String;

}
