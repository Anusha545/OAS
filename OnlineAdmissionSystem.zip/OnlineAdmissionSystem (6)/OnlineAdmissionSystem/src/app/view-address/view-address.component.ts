import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Address } from '../model/address';
import { AddressServiceService } from '../service/address-service.service';

@Component({
  selector: 'app-view-address',
  templateUrl: './view-address.component.html',
  styleUrls: ['./view-address.component.css']
})
export class ViewAddressComponent implements OnInit {
  msg:String="";
  address:Address[]=[];
  constructor(private addressService:AddressServiceService,private router:Router) { }

  ngOnInit() {
    this.addressService.extractAddress().subscribe(response=>{ this.address=response;})
  }
  public deleteAddress(addressId:number){
    console.log(addressId);
    this.addressService.deleteAddress(addressId).subscribe(response=>{
      console.log(response);
      this.msg=`${addressId}`+" "+"is deleted";
      alert("address Id is deleted");
      window.location.reload();
    })
  }
  public EditAddress(addressId:number){
    console.log(addressId);
      this.router.navigate(['UpdateAddress',addressId])
    }
  }



