import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByStatusComponent } from './payment-by-status.component';

describe('PaymentByStatusComponent', () => {
  let component: PaymentByStatusComponent;
  let fixture: ComponentFixture<PaymentByStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentByStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentByStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
