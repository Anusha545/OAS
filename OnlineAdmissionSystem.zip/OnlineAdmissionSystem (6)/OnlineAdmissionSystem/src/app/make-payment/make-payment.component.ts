import { Component, OnInit } from '@angular/core';
import { Payment } from '../model/payment';
import { PaymentServiceService } from '../service/payment-service.service';

@Component({
  selector: 'app-make-payment',
  templateUrl: './make-payment.component.html',
  styleUrls: ['./make-payment.component.css']
})
export class MakePaymentComponent implements OnInit {
payment:Payment=new Payment();
msg:String="";
errormsg:String="";
errorMsg:String="";

  constructor(private ps:PaymentServiceService) { }

  ngOnInit() {
  }
  public addPayment():void{
    console.log(this.payment);
    this.ps.addPayment(this.payment).subscribe((p)=>
    {
      this.payment=p;
      console.log(this.msg);
      this.errorMsg=(p.errorMsg);
      console.log(p.errorMsg);
      if(p!=null){
        alert("payment has been added")
      }
      
  }
  );
  

}

}
