import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Program } from '../model/program';
import { ProgramServiceService } from '../service/program-service.service';

@Component({
  selector: 'app-viewprogram',
  templateUrl: './viewprogram.component.html',
  styleUrls: ['./viewprogram.component.css']
})
export class ViewprogramComponent implements OnInit {

  msg:String="";
program:Program[]=[];
  constructor(private programService:ProgramServiceService,private router:Router) { }

  ngOnInit() {
    this.programService.extractProgram().subscribe(response=>{ this.program=response;})}

    public deleteProgram(programId:number){
      console.log(programId);
      this.programService.deleteProgram(programId).subscribe(response=>{
        console.log(response);
        this.msg=`${programId}`+" "+"is deleted";
        alert("program Id is deleted");
        window.location.reload();
      }) 

}
public EditProgram(programId:number){
  console.log(programId);
  this.router.navigate(['UpdateProgram',programId])
}
}
