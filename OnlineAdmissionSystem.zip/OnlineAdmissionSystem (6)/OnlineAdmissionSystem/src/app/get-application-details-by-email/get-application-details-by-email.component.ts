import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Application } from '../model/application';
import { ApplicationServiceService } from '../service/application-service.service';

@Component({
  selector: 'app-get-application-details-by-email',
  templateUrl: './get-application-details-by-email.component.html',
  styleUrls: ['./get-application-details-by-email.component.css']
})
export class GetApplicationDetailsByEmailComponent implements OnInit {
  bEmail:String;
  msg:String="";
  applications:Application[]=[];

  constructor(private bs:ApplicationServiceService,private router:Router) { 

  }

  ngOnInit() {
  }

  public Email(){
    console.log(this.bEmail);
    this.bs.extractByEmail(this.bEmail).subscribe(response=>{
      this.applications=response;
      console.log(response);
        alert(this.bEmail);
      
  
  })
}
}