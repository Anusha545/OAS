import { Component, OnInit } from '@angular/core';
import { College } from '../model/college';
import { CollegeServiceService } from '../service/college-service.service';

@Component({
  selector: 'app-create-college',
  templateUrl: './create-college.component.html',
  styleUrls: ['./create-college.component.css']
})
export class CreateCollegeComponent implements OnInit {
  college:College=new College(); 
  msg:String="";
  constructor(private ps:CollegeServiceService) { }

  ngOnInit() {
  }
  public createCollege():void{
    console.log(this.college);
    this.ps.addCollege(this.college).subscribe((p)=>
    {
      this.msg=p;
      console.log(this.msg);
      alert("College has been added");
     
    }
  );
  }
}
