import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Application } from '../model/application';
import { ApplicationServiceService } from '../service/application-service.service';

@Component({
  selector: 'app-view-application',
  templateUrl: './view-application.component.html',
  styleUrls: ['./view-application.component.css']
})
export class ViewApplicationComponent implements OnInit {
  msg:String="";
  applications:Application[]=[];
  constructor(private applicationservice:ApplicationServiceService,private router:Router) { }

  ngOnInit() {
    this.applicationservice.extractApplication().subscribe(response=>{ this.applications=response;})
  }
  public deleteApplication(Id:number){
    console.log(Id);
    this.applicationservice.deleteApplicationById(Id).subscribe(response=>{
      console.log(response);
      this.msg=`${Id}`+" "+"is deleted";
      alert("application Id is deleted");
      window.location.reload();
    })
  }
  public EditApplication(Id:number){
    console.log(Id);
      this.router.navigate(['UpdateApplication',Id])
    }
  }


