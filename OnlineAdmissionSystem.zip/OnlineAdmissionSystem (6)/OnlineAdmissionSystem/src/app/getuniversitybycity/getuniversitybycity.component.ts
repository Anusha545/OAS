import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { University } from '../model/university';
import { UniversityserviceService } from '../service/universityservice.service';

@Component({
  selector: 'app-getuniversitybycity',
  templateUrl: './getuniversitybycity.component.html',
  styleUrls: ['./getuniversitybycity.component.css']
})
export class GetuniversitybycityComponent implements OnInit {

universitycity:String="";
msg:String="";
university:University[]=[];

  constructor(private bs:UniversityserviceService,private router:Router) { 

  }

  
  ngOnInit() {
  }
  public city(){
    console.log(this.universitycity);
    this.bs.extractBycity(this.universitycity).subscribe(response=>{
      this.university=response;
      console.log(response);
        alert(this.universitycity);
      
    })
  }
}