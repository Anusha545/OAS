import { Component, OnInit } from '@angular/core';
import { Branch } from '../model/branch';
import { BranchServiceService } from '../service/branch-service.service';

@Component({
  selector: 'app-create-branch-component',
  templateUrl: './create-branch-component.component.html',
  styleUrls: ['./create-branch-component.component.css']
})
export class CreateBranchComponentComponent implements OnInit {
branch:Branch=new Branch();
  branchName:String="";
	branchDescription:String="";
  msg="";
  constructor(private branchService:BranchServiceService) { }

  ngOnInit() {
  }
  public createBranch():void{
    console.log(this.branch);
    this.branchService.addBranch(this.branch).subscribe((p)=>
    {
      this.msg=p;
      console.log(this.msg);
      alert("branch has been added");
     
    }
  );
  

}
}
