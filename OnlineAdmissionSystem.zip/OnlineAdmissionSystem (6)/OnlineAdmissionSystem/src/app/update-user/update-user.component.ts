import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../model/user';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
    userId:String;
   firstName:String;
   middleName:String;
   lastName:String;
   email:String;
   mobileNumber:String;
   aadharcardNo:String;
   uFirstName:String;
   user:User;
  constructor(private r:ActivatedRoute,private userService:UserServiceService,private router:Router) { }

  ngOnInit() {
    this.userId=this.r.snapshot.params['p'];
    this.userService.extractUserById(this.userId).subscribe(response=>{
      this.user=response;
      this.uFirstName=this.user.firstName;
    })
}
 public updateUser(){
  this.user.firstName=this.uFirstName;
  this.userService.updateUserDetails(this.user,this.user.userId).subscribe(response=>{
    console.log(response);
    alert("User is updated");
    this.router.navigate(['viewUser']);
  })
 
  }

}
