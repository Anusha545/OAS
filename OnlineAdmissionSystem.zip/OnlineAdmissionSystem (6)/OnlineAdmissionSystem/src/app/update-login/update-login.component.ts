import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-update-login',
  templateUrl: './update-login.component.html',
  styleUrls: ['./update-login.component.css']
})
export class UpdateLoginComponent implements OnInit {
  loginId:String="";
  uloginId:String="";
  newpassword:String="";
  npassword:String="";
  login:Login;
  constructor(private r:ActivatedRoute,private userService:UserServiceService,private router:Router) { }

  ngOnInit() {
    this.loginId=this.r.snapshot.params['r'];
    this.userService.extractLoginById(this.loginId).subscribe(response=>{
      this.login=response;
      this.npassword=this.login.password;
    })
  }
  
  public updateLogin(){
    this.login.loginId=this.loginId;
    this.login.password=this.npassword;
    this.userService.updateLoginDetails(this.login,this.login.loginId).subscribe(response=>{
      console.log(response);
      alert("Password is updated");
      this.router.navigate(['viewLogin']);
    })
   
    }


}
