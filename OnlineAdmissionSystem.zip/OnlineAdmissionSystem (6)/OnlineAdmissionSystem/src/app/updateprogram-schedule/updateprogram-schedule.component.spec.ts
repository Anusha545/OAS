import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateprogramScheduleComponent } from './updateprogram-schedule.component';

describe('UpdateprogramScheduleComponent', () => {
  let component: UpdateprogramScheduleComponent;
  let fixture: ComponentFixture<UpdateprogramScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateprogramScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateprogramScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
