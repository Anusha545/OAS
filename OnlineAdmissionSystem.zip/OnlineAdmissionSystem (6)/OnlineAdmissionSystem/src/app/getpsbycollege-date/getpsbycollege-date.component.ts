import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getpsbycollege-date',
  templateUrl: './getpsbycollege-date.component.html',
  styleUrls: ['./getpsbycollege-date.component.css']
})
export class GetpsbycollegeDateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
