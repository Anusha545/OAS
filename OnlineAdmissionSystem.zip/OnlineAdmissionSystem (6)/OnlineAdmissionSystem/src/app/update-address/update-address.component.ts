import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Address } from '../model/address';
import { AddressServiceService } from '../service/address-service.service';

@Component({
  selector: 'app-update-address',
  templateUrl: './update-address.component.html',
  styleUrls: ['./update-address.component.css']
})
export class UpdateAddressComponent implements OnInit {

  address:Address;
  addressId:number;
  bcity:String;
  bdistrict:String;
  constructor(private r:ActivatedRoute,private as:AddressServiceService,private router:Router) { }

  ngOnInit() {
    this.addressId=this.r.snapshot.params['p'];
    this.as.extractById(this.addressId).subscribe(response=>
 {
  this.address=response;
  this.bcity=this.address.city;
  this.bdistrict=this.address.district; 
 })
}

public updateAddress(){
  this.address.city=this.bcity;
  this.address.district=this.bdistrict;
  
    this.as.updateById(this.address,this.address.addressId).subscribe(response=>{
      console.log(response);
      alert("address is updated");
      this.router.navigate(['ViewAddress']);
    })
   }
  
   
    }
  


