import { Component, OnInit } from '@angular/core';
import { Program } from '../model/program';
import { ProgramServiceService } from '../service/program-service.service';

@Component({
  selector: 'app-create-program',
  templateUrl: './create-program.component.html',
  styleUrls: ['./create-program.component.css']
})
export class CreateProgramComponent implements OnInit {
  program:Program=new Program();
  msg:String="";
    constructor(private ps:ProgramServiceService) { }
  
    ngOnInit() {
    }
    public createProgram():void{
      console.log(this.program);
      this.ps.addProgram(this.program).subscribe((p)=>
      {
        this.msg=p;
        console.log(this.msg);
        alert("program has been created");
        window.location.reload();
      }
    );
    }
  }
