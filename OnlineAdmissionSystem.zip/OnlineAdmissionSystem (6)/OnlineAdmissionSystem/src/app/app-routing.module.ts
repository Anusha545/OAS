import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactComponent } from './contact/contact.component';
import { CreateAddressComponent } from './create-address/create-address.component';
import { CreateApplicationComponent } from './create-application/create-application.component';
import { CreateBranchComponentComponent } from './create-branch-component/create-branch-component.component';
import { CreateCollegeComponent } from './create-college/create-college.component';
import { CreateNewPasswordComponent } from './create-new-password/create-new-password.component';
import { CreateProgramComponent } from './create-program/create-program.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { CreatecourseComponent } from './createcourse/createcourse.component';
import { CreateprogramscheduleComponent } from './createprogramschedule/createprogramschedule.component';
import { CreateuniversityComponent } from './createuniversity/createuniversity.component';

//import { error } from 'console';
import { ErrorComponent } from './error/error.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { GetApplicationDetailsByEmailComponent } from './get-application-details-by-email/get-application-details-by-email.component';
import { GetApplicationDetailsByStatusComponent } from './get-application-details-by-status/get-application-details-by-status.component';
import { GetBranchByIdComponent } from './get-branch-by-id/get-branch-by-id.component';
import { GetBranchByNameComponent } from './get-branch-by-name/get-branch-by-name.component';
import { GetDetailsByCollegeNameComponent } from './get-details-by-college-name/get-details-by-college-name.component';
import { GetDetailsByCourseNameComponent } from './get-details-by-course-name/get-details-by-course-name.component';
import { GetDetailsbyEligiblityComponent } from './get-detailsby-eligiblity/get-detailsby-eligiblity.component';
import { GetProgramByEligibilityComponent } from './get-program-by-eligibility/get-program-by-eligibility.component';
import { GetProgramByIdComponent } from './get-program-by-id/get-program-by-id.component';
import { GetProgramByNameComponent } from './get-program-by-name/get-program-by-name.component';
import { GetcollegedetailsbybranchnameComponent } from './getcollegedetailsbybranchname/getcollegedetailsbybranchname.component';
import { GetcollegedetailsbycollegenameComponent } from './getcollegedetailsbycollegename/getcollegedetailsbycollegename.component';
import { GetcollegedetailsbycoursenameComponent } from './getcollegedetailsbycoursename/getcollegedetailsbycoursename.component';
import { GetcollegedetailsbyprogramnameComponent } from './getcollegedetailsbyprogramname/getcollegedetailsbyprogramname.component';
import { GetcoursebyIdComponent } from './getcourseby-id/getcourseby-id.component';
import { GetpsbyDateComponent } from './getpsby-date/getpsby-date.component';
import { GetpsbycollegenameComponent } from './getpsbycollegename/getpsbycollegename.component';
import { GetuniversitybyIdComponent } from './getuniversityby-id/getuniversityby-id.component';
import { GetuniversitybycityComponent } from './getuniversitybycity/getuniversitybycity.component';
import { GetuniversitybycollegenameComponent } from './getuniversitybycollegename/getuniversitybycollegename.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MakePaymentComponent } from './make-payment/make-payment.component';
import { Payment } from './model/payment';
import { PaymentByApplicationIdComponent } from './payment-by-application-id/payment-by-application-id.component';
import { PaymentByEmailComponent } from './payment-by-email/payment-by-email.component';
import { PaymentByPaymentIdComponent } from './payment-by-payment-id/payment-by-payment-id.component';
import { PaymentByStatusComponent } from './payment-by-status/payment-by-status.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UpdateAddressComponent } from './update-address/update-address.component';
import { UpdateApplicationComponent } from './update-application/update-application.component';
import { UpdateBranchComponent } from './update-branch/update-branch.component';
import { UpdateCollegeComponent } from './update-college/update-college.component';
import { UpdateCourseComponent } from './update-course/update-course.component';
import { UpdateLoginComponent } from './update-login/update-login.component';
import { UpdatePaymentComponent } from './update-payment/update-payment.component';
import { UpdateUniversityComponent } from './update-university/update-university.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { UpdateprogramScheduleComponent } from './updateprogram-schedule/updateprogram-schedule.component';
import { UpdateprogramComponent } from './updateprogram/updateprogram.component';
import { ViewAddressComponent } from './view-address/view-address.component';
import { ViewApplicationComponent } from './view-application/view-application.component';
import { ViewBranchComponent } from './view-branch/view-branch.component';
import { ViewCollegeComponent } from './view-college/view-college.component';
import { ViewLoginComponent } from './view-login/view-login.component';
import { ViewPaymentComponent } from './view-payment/view-payment.component';
import { ViewUniversityComponent } from './view-university/view-university.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewcourseComponent } from './viewcourse/viewcourse.component';
import { ViewcoursedetailsbyadminComponent } from './viewcoursedetailsbyadmin/viewcoursedetailsbyadmin.component';
import { ViewprogramComponent } from './viewprogram/viewprogram.component';
import { ViewprogramscheduleIdComponent } from './viewprogramschedule-id/viewprogramschedule-id.component';
import { ViewuniversitybyadminComponent } from './viewuniversitybyadmin/viewuniversitybyadmin.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { WelcomestudentComponent } from './welcomestudent/welcomestudent.component';

//localhost:4200//Login
const routes: Routes = [{path:"",component:HomeComponent},
{path:"login",component:LoginComponent},
{path:"NewUser",component:CreateUserComponent},
{path:"contact",component:ContactComponent},
{path:"aboutUs",component:AboutusComponent},
{path:"viewUser",component:ViewUserComponent},
{path:"viewLogin",component:ViewLoginComponent},
{path:"welcome/:id",component:WelcomeComponent},
{path:"welcomestudent/:p",component:WelcomestudentComponent},
{path:"forgotpassword",component:ForgotPasswordComponent},
{path:"logout",component:LoginComponent},
{path:"UpdateForm/:p",component:UpdateUserComponent},
{path:"UpdateLogin/:r",component:UpdateLoginComponent},
{path:"ResetPassword",component:ResetPasswordComponent},
{path:"CreateNewPassword",component:CreateNewPasswordComponent},
{path:"MakePayment",component:MakePaymentComponent},
{path:"viewPayment",component:ViewPaymentComponent},
{path:"viewByEmail",component:PaymentByEmailComponent},
{path:"BranchUpdate/:p",component:UpdateBranchComponent},
{path:"viewByStatus",component:PaymentByStatusComponent},
{path:"CreateUniversity",component:CreateuniversityComponent},
{path:"viewByApplicationId",component:PaymentByApplicationIdComponent},
{path:"UpdatePayment/:p",component:UpdatePaymentComponent},
{path:"viewByPaymentId",component:PaymentByPaymentIdComponent},
{path:"GetBranchById",component:GetBranchByIdComponent},
{path:"GetProgramById",component:GetProgramByIdComponent},
{path:"GetBranchByName",component:GetBranchByNameComponent},
{path:"getCourseById",component:GetcoursebyIdComponent},
{path:"getUniversityById",component:GetuniversitybyIdComponent},
{path:"GetProgramByName",component:GetProgramByNameComponent},
{path:"GetProgramByEligibility",component:GetProgramByEligibilityComponent},
{path:"CreateAddress",component:CreateAddressComponent},
{path:"CreateBranch",component:CreateBranchComponentComponent},
{path:"ViewAddress",component:ViewAddressComponent},
{path:"ViewProgram",component:ViewprogramComponent},
{path:"ViewCourse",component:ViewcourseComponent},
{path:"ViewUniversity",component:ViewUniversityComponent},
{path:"CreateCourse",component:CreatecourseComponent},
{path:"UpdateApplication/:p",component:UpdateApplicationComponent},
{path:"Up/:p",component:UpdateUniversityComponent},
{path:"CreateProgram",component:CreateProgramComponent},
{path:"GetCourseByName",component:GetDetailsByCourseNameComponent},
{path:"viewcoursebyadmin",component:ViewcoursedetailsbyadminComponent},
{path:"viewuniversitybyadmin",component:ViewuniversitybyadminComponent},
{path:"createProgramSchedule",component:CreateprogramscheduleComponent},
{path:"GetCourseByEligibility",component:GetDetailsbyEligiblityComponent},
{path:"GetDetailsByCollegeName",component:GetDetailsByCollegeNameComponent},
{path:"GetUniversityBycity",component:GetuniversitybycityComponent},
{path:"GetUniversityBycollegename",component:GetuniversitybycollegenameComponent},
{path:"Getpsbystartdate",component:GetpsbyDateComponent},
{path:"UpdateAddress/:p",component:UpdateAddressComponent},
{path:"UpdateProgramSchedule/:p",component:UpdateprogramScheduleComponent},
{path:"CreateApplication",component:CreateApplicationComponent},
{path:"UpdateProgram/:p",component:UpdateprogramComponent},
{path:"viewApplication",component:ViewApplicationComponent},
{path:"CollegeUpdate/:p",component:UpdateCollegeComponent},
{path:"Getpsbycollegename",component:GetpsbycollegenameComponent},
{path:"ViewCollege",component:ViewCollegeComponent},
{path:"viewBySchedule",component:ViewprogramscheduleIdComponent},
{path:"GetCollegedetailsByCollegeName",component:GetcollegedetailsbycollegenameComponent},
{path:"GetCollegedetailsByCourseName",component:GetcollegedetailsbycoursenameComponent},
{path:"GetCollegedetailsByProgramName",component:GetcollegedetailsbyprogramnameComponent},
{path:"GetCollegedetailsByBranchName",component:GetcollegedetailsbybranchnameComponent},
{path:"CreateCollege",component:CreateCollegeComponent},
{path:"UpdateCourse/:p",component:UpdateCourseComponent},
{path:"ViewBranch",component:ViewBranchComponent},
{path:"GetApplicationByEmail",component:GetApplicationDetailsByEmailComponent},
{path:"GetApplicationByStatus",component:GetApplicationDetailsByStatusComponent},
{path:"**",component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

