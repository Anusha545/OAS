import { Component, OnInit } from '@angular/core';
import { ProgramScheduleId } from '../model/program-schedule-id';
import { ProgramscheduleIdService } from '../service/programschedule-id.service';

@Component({
  selector: 'app-createprogramschedule',
  templateUrl: './createprogramschedule.component.html',
  styleUrls: ['./createprogramschedule.component.css']
})
export class CreateprogramscheduleComponent implements OnInit {

  programscheduleId:ProgramScheduleId=new ProgramScheduleId(); 
  msg:String="";
  constructor(private ps:ProgramscheduleIdService) { }

  ngOnInit() {
  }
  public createProgramScheduledId():void{
    console.log(this.programscheduleId);
    this.ps.addSchedule(this.programscheduleId).subscribe((p)=>
    {
      this.msg=p;
      console.log(this.msg);
      alert("schedule has been added");
     
    }
  );
  }
}
