import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateprogramscheduleComponent } from './createprogramschedule.component';

describe('CreateprogramscheduleComponent', () => {
  let component: CreateprogramscheduleComponent;
  let fixture: ComponentFixture<CreateprogramscheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateprogramscheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateprogramscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
