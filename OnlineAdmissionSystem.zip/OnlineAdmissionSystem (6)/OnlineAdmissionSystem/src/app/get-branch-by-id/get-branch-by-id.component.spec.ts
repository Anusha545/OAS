import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetBranchByIdComponent } from './get-branch-by-id.component';

describe('GetBranchByIdComponent', () => {
  let component: GetBranchByIdComponent;
  let fixture: ComponentFixture<GetBranchByIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetBranchByIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetBranchByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
